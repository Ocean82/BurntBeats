"use client"

import MusicGenerator from "../music-generator"

export default function EnhancedMusicGenerator() {
  return <MusicGenerator />
}
