import EnhancedMusicGenerator from "./enhanced-music-generator"

export default function Page() {
  return <EnhancedMusicGenerator />
}
